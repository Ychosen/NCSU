import networkx as nx
import numpy as np
import matplotlib.pyplot as plt


BETA_1 = 0.2
BETA_2 = 0.01
DELTA_1 = 0.7
DELTA_2 = 0.6


def read_file(filename):
    graph = nx.Graph()
    file = open(filename, 'r')
    first_line = True
    edges = []
    nodes = set()
    nodes_num = 0
    for line in file:
        if first_line:
            nodes_num = line.split()[0]
            first_line = False
            continue
        edge = line.split()
        nodes.union(set(edge))
        edges.append(edge)
    graph.add_edges_from(edges)
    return graph


def effective_strength(graph, beta, delta):
    e = nx.adjacency_spectrum(graph, weight='None')
    # A = nx.adjacency_matrix(graph, weight='None')
    # e = np.linalg.eigvals(A.A)
    lambda1 = max(e)
    s = lambda1 * (beta / delta)
    return lambda1, s


def plot_function_of_beta(lambda1, delta):
    x = np.arange(0, 1, 0.01)
    y = x * (lambda1 / delta)
    plt.title('How beta affects s')
    plt.plot(x, y)
    plt.hlines(1, 0, 1, colors="r", linestyles="dashed")
    plt.xlabel('beta')
    plt.ylabel('s')
    plt.show()
    min_beta = delta / lambda1
    return min_beta


def plot_function_of_delta(lambda1, beta):
    x = np.arange(0, 1, 0.01)
    y = (lambda1 * beta) / x
    plt.title('How delta affects s')
    plt.plot(x, y)
    plt.hlines(1, 0, 1, colors="r", linestyles="dashed")
    plt.xlabel('delta')
    plt.ylabel('s')
    plt.show()
    max_delta = lambda1 * beta
    return max_delta


def analyse_model(graph, beta, delta):
    print('Analysing model: beta = ' + str(beta) + ' delta = ' + str(delta) + ' :')
    lambda1, s = effective_strength(graph, beta, delta)
    print('The effective strength is ' + str(s.real))
    min_beta = plot_function_of_beta(lambda1, delta)
    print('The minimum transmission probability that results in a network-wide epidemic is ' + str(min_beta.real))
    max_delta = plot_function_of_delta(lambda1, beta)
    print('The maximum healing probability that results in a network-wide epidemic is ' + str(max_delta.real))


# graph = read_file('static.network')
# analyse_model(graph, BETA_1, DELTA_1)
# analyse_model(graph, BETA_2, DELTA_2)
