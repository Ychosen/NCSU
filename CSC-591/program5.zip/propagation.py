from random import *

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import copy
from strengh import *

TRANS_PROB = 0.2  # Beta
# TRANS_PROB = 0.01       # Beta
HEALING_PROB = 0.7  # Theta
# HEALING_PROB = 0.6      # Theta
INIT_INFECT = 10  # c
STEPS = 100  # t
K = 200  # k


class GraphInfo:
    graph = nx.Graph()
    nodes = {}
    infected_nodes = []

    def __init__(self, graph, nodes, c):
        self.graph = graph
        self.nodes = nodes
        seed(random())
        self.infected_nodes = sample(list(self.nodes.keys()), c)

    def infect(self):
        susceptible_nodes = set()
        for node in self.infected_nodes:
            for nei in self.graph.neighbors(node):
                if self.nodes[nei] != 1:
                    susceptible_nodes.add(nei)

        for node in susceptible_nodes:
            if random() <= TRANS_PROB:
                self.nodes[node] = 1
                self.infected_nodes.append(node)

    # def infect(self):
    #     for node in self.infected_nodes:
    #         for nei in self.graph.neighbors(node):
    #             if self.nodes[nei] != 1 and random() <= TRANS_PROB:
    #                 self.nodes[node] = 1
    #                 self.infected_nodes.append(node)

    def heal(self):
        for node in self.infected_nodes[:]:
            if random() <= HEALING_PROB:
                self.nodes[node] = 0
                self.infected_nodes.remove(node)


def read_file(filename):
    graph = nx.Graph()
    file = open(filename, 'r')
    first_line = True
    edges = []
    nodes = []
    nodes_num = 0
    for line in file:
        if first_line:
            nodes_num = int(line.split()[0])
            first_line = False
            continue
        edge = list(map(int, line.split()))
        nodes += edge
        edges.append(edge)
    graph.add_edges_from(edges)
    nodes = {int(node): 0 for node in set(nodes)}
    return graph, nodes, nodes_num


def propagation(graph, nodes_num):
    fraction = []
    for i in range(STEPS):
        graph.infect()
        graph.heal()
        fraction.append(len(graph.infected_nodes) / nodes_num)
    return fraction


def propagation_simu(graph, nodes, nodes_num):
    fractions = [0] * 100
    for _ in range(10):
        g = GraphInfo(graph, dict(nodes), nodes_num // 10)
        fraction = propagation(g, nodes_num)
        fractions = [(fractions[i] + fraction[i]) for i in range(100)]
    fractions = list(map(lambda x: x / 10, fractions))
    plt.plot(list(range(100)), fractions)
    # plt.legend()
    plt.show()
    print(fractions)


def policy_A(graph, k):
    remove_nodes = sample(list(graph.nodes()), k)
    for node in remove_nodes:
        graph.remove_node(node)
    return graph


def policy_B(graph, k):
    nodes_by_degree = sorted(list(graph.nodes()), reverse=True, key=lambda x: graph.degree()[x])
    for i in range(k):
        graph.remove_node(nodes_by_degree[i])
    return graph


def policy_C(graph, k):
    for i in range(k):
        print("round: ", i)
        nodes_by_degree = sorted(list(graph.nodes()), reverse=True, key=lambda x: graph.degree()[x])
        graph.remove_node(nodes_by_degree[0])
    return graph


def policy_D(graph, k):
    A = nx.adjacency_matrix(graph, weight='None')
    w, v = np.linalg.eig(A.A)
    index_max = np.argmax(w)
    evector_max = v[:, index_max]
    np.abs(evector_max)
    k_indices = np.argpartition(evector_max, len(evector_max)-k)[-k:]
    for node in k_indices:
        graph.remove_node(node)
    return graph


if __name__ == "__main__":
    func = policy_D
    graph, nodes, nodes_num = read_file("static.network")
    # propagation_simu(graph, nodes, nodes_num)
    # strenths = []
    # for k in [10, 50, 100, 200, 500, 1000, 2000]:
    #     immuned_graph = func(copy.deepcopy(graph), k)
    #     _, s = effective_strength(immuned_graph, TRANS_PROB, HEALING_PROB)
    #     strenths.append(s)
    #     print("strength use policy A: ", str(s.real))
    # plt.plot([10, 50, 100, 200, 500, 1000, 2000], strenths)
    # plt.legend()
    # plt.show()
    # print("strength: ", s)

    immuned_graph = func(copy.deepcopy(graph), K)
    _, s = effective_strength(immuned_graph, TRANS_PROB, HEALING_PROB)
    print(s)
    # propagation_simu(immuned_graph, {node: 0 for node in immuned_graph.nodes()}, len(immuned_graph.nodes()))
